/******/ (() => { // webpackBootstrap
document.addEventListener("DOMContentLoaded", function () {
  /* animation */
  // const animItems = document.querySelectorAll(".animate");
  // const classAnimation = "fade-to-right"; //set class animation
  // if (animItems.length) {
  //   function handleIntersection(entries, observer) {
  //     entries.forEach((entry) => {
  //       if (entry.isIntersecting) {
  //         entry.target.classList.add(classAnimation);
  //         observer.unobserve(entry.target);
  //       }
  //     });
  //   }
  //   const observer = new IntersectionObserver(handleIntersection, {
  //     threshold: 0.1,
  //   });
  //   animItems.forEach((animation) => {
  //     observer.observe(animation);
  //   });
  // }
  // /* FAQ */
  // const faqItems = document.querySelectorAll(".faq-item");
  // if (faqItems.length) {
  //   faqItems.forEach((item) => {
  //     item.addEventListener("click", () => {
  //       item.classList.toggle("active");
  //     });
  //   });
  // }
  /* tabs */
  // const tabLinks = document.querySelectorAll(".tabs a");
  // if (tabLinks.length) {
  //   tabLinks.forEach(function (link) {
  //     link.addEventListener("click", function (event) {
  //       event.preventDefault();
  //       const target = this.getAttribute("data-rel");
  //       tabLinks.forEach(function (link) {
  //         link.classList.remove("active");
  //       });
  //       this.classList.add("active");
  //       const targetElement = document.getElementById(target);
  //       const tabBoxes = document.querySelectorAll(".tab-box");
  //       tabBoxes.forEach(function (box) {
  //         box.classList.remove("visible");
  //       });
  //       targetElement.classList.add("visible");
  //     });
  //   });
  // }
});

/******/ })()
;